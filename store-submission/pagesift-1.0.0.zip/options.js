// src/lib/providers.ts
var ApiError = class extends Error {
  kind;
  status;
  constructor(kind, message, status) {
    super(message);
    this.name = "ApiError";
    this.kind = kind;
    this.status = status;
  }
};
function buildKeyCheckRequest(provider, apiKey) {
  switch (provider) {
    case "openai":
      return { url: "https://api.openai.com/v1/models", method: "GET", headers: { authorization: `Bearer ${apiKey}` } };
    case "anthropic":
      return {
        url: "https://api.anthropic.com/v1/models?limit=1",
        method: "GET",
        headers: {
          "x-api-key": apiKey,
          "anthropic-version": "2023-06-01",
          "anthropic-dangerous-direct-browser-access": "true"
        }
      };
    case "openrouter":
      return { url: "https://openrouter.ai/api/v1/key", method: "GET", headers: { authorization: `Bearer ${apiKey}` } };
  }
}
function errorMessage(json) {
  const err = json?.error;
  if (typeof err === "string") return err;
  const msg = err?.message;
  return typeof msg === "string" ? msg : "";
}
function httpError(status, json) {
  const detail = errorMessage(json);
  if (status === 401 || status === 403) {
    return new ApiError("auth", detail || "The API key was rejected. Check it in Settings.", status);
  }
  if (status === 402) return new ApiError("rate_limit", detail || "Out of credits on this API account.", status);
  if (status === 429) return new ApiError("rate_limit", detail || "Rate limit or quota reached. Try again shortly.", status);
  if (status >= 500) return new ApiError("server", detail || `The provider had an error (HTTP ${status}).`, status);
  return new ApiError("bad_request", detail || `Request failed (HTTP ${status}).`, status);
}
async function send(req, fetchImpl, signal) {
  let res;
  try {
    const init2 = { method: req.method, headers: req.headers };
    if (req.body !== void 0) init2.body = req.body;
    if (signal) init2.signal = signal;
    res = await fetchImpl(req.url, init2);
  } catch (e) {
    if (e.name === "AbortError") throw e;
    throw new ApiError("network", "Couldn't reach the API. Check your connection and that access to the API was allowed.");
  }
  let json = null;
  try {
    json = await res.json();
  } catch {
    if (res.ok) throw new ApiError("parse", "The provider returned a non-JSON reply.", res.status);
  }
  if (!res.ok) throw httpError(res.status, json);
  return json;
}
async function checkKey(provider, apiKey, fetchImpl = fetch) {
  await send(buildKeyCheckRequest(provider, apiKey), fetchImpl);
}

// src/lib/settings.ts
var PROVIDERS = {
  openai: {
    label: "OpenAI",
    origin: "https://api.openai.com/*",
    defaultModel: "gpt-5.4-mini",
    keyPrefix: "sk-",
    keyUrl: "https://platform.openai.com/api-keys"
  },
  anthropic: {
    label: "Anthropic",
    origin: "https://api.anthropic.com/*",
    defaultModel: "claude-haiku-4-5",
    keyPrefix: "sk-ant-",
    keyUrl: "https://console.anthropic.com/settings/keys"
  },
  openrouter: {
    label: "OpenRouter",
    origin: "https://openrouter.ai/*",
    defaultModel: "openai/gpt-5.4-mini",
    keyPrefix: "sk-or-",
    keyUrl: "https://openrouter.ai/settings/keys"
  }
};
var PROVIDER_IDS = Object.keys(PROVIDERS);
var MIN_CHARS = 2e3;
var MAX_CHARS = 12e4;
var DEFAULT_SETTINGS = {
  provider: "openai",
  keys: { openai: "", anthropic: "", openrouter: "" },
  models: { openai: "", anthropic: "", openrouter: "" },
  maxChars: 3e4,
  includeLinks: true
};
function isProvider(value) {
  return typeof value === "string" && value in PROVIDERS;
}
function strings(raw) {
  const out = { openai: "", anthropic: "", openrouter: "" };
  if (raw && typeof raw === "object") {
    for (const id of PROVIDER_IDS) {
      const v = raw[id];
      if (typeof v === "string") out[id] = v.trim();
    }
  }
  return out;
}
function normalizeSettings(raw) {
  const r = raw && typeof raw === "object" ? raw : {};
  const chars = Number(r.maxChars);
  return {
    provider: isProvider(r.provider) ? r.provider : DEFAULT_SETTINGS.provider,
    keys: strings(r.keys),
    models: strings(r.models),
    maxChars: Number.isFinite(chars) ? Math.min(MAX_CHARS, Math.max(MIN_CHARS, Math.round(chars))) : DEFAULT_SETTINGS.maxChars,
    includeLinks: typeof r.includeLinks === "boolean" ? r.includeLinks : DEFAULT_SETTINGS.includeLinks
  };
}
function keyLooksValid(provider, key) {
  const k = key.trim();
  if (k.length < 20 || /\s/.test(k)) return false;
  if (provider === "openai") return k.startsWith("sk-") && !k.startsWith("sk-ant-") && !k.startsWith("sk-or-");
  return k.startsWith(PROVIDERS[provider].keyPrefix);
}
var STORAGE_KEY = "settings";
async function loadSettings(storage = chrome.storage.local) {
  const got = await storage.get(STORAGE_KEY);
  return normalizeSettings(got[STORAGE_KEY]);
}
async function saveSettings(settings2, storage = chrome.storage.local) {
  await storage.set({ [STORAGE_KEY]: normalizeSettings(settings2) });
}

// src/options/options.ts
var $ = (id) => document.getElementById(id);
var settings;
function selected() {
  const v = document.querySelector('input[name="provider"]:checked')?.value;
  return v ?? settings.provider;
}
function say(text, tone = "") {
  const el = $("msg");
  el.textContent = text;
  el.className = `msg ${tone}`;
}
function renderProviders() {
  const box = $("providers");
  box.replaceChildren();
  for (const id of PROVIDER_IDS) {
    const p = PROVIDERS[id];
    const label = document.createElement("label");
    const input = Object.assign(document.createElement("input"), { type: "radio", name: "provider", value: id });
    input.checked = id === settings.provider;
    input.onchange = () => {
      stash();
      settings.provider = id;
      showProvider();
    };
    const name = Object.assign(document.createElement("b"), { textContent: p.label });
    const sub = document.createElement("small");
    if (settings.keys[id]) sub.append(Object.assign(document.createElement("span"), { className: "dot" }), "Key saved");
    else sub.textContent = `Default: ${p.defaultModel}`;
    label.append(input, name, sub);
    box.append(label);
  }
}
function showProvider() {
  const id = settings.provider;
  const p = PROVIDERS[id];
  $("key-label").textContent = `${p.label} API key`;
  $("key").value = settings.keys[id];
  $("key").placeholder = `${p.keyPrefix}\u2026`;
  $("key-link").href = p.keyUrl;
  $("key-link").textContent = `Get a ${p.label} key`;
  $("model").value = settings.models[id];
  $("model").placeholder = p.defaultModel;
  say("");
}
function stash() {
  const id = settings.provider;
  settings.keys[id] = $("key").value.trim();
  settings.models[id] = $("model").value.trim();
  settings.maxChars = Number($("max-chars").value);
  settings.includeLinks = $("include-links").checked;
}
async function requestAccess(id) {
  try {
    return await chrome.permissions.request({ origins: [PROVIDERS[id].origin] });
  } catch {
    return false;
  }
}
async function save(e) {
  e.preventDefault();
  const id = selected();
  const granted = await requestAccess(id);
  stash();
  settings.provider = id;
  settings = normalizeSettings(settings);
  await saveSettings(settings);
  $("max-chars").value = String(settings.maxChars);
  renderProviders();
  const key = settings.keys[id];
  if (!key) return say("Saved. Add a key to start extracting.", "");
  if (!granted) return say(`Saved, but PageSift can't reach ${PROVIDERS[id].label} until you allow access.`, "err");
  if (!keyLooksValid(id, key)) return say(`Saved. That doesn't look like a ${PROVIDERS[id].label} key, though.`, "err");
  say("Saved \u2713 Open any page and click the PageSift icon.", "ok");
}
async function test() {
  const id = selected();
  const key = $("key").value.trim();
  if (!key) return say("Enter a key first.", "err");
  if (!await requestAccess(id)) return say("Access to the provider wasn't allowed.", "err");
  say("Checking\u2026");
  try {
    await checkKey(id, key);
    say(`Key works \u2713 (${PROVIDERS[id].label})`, "ok");
  } catch (err) {
    say(err instanceof ApiError ? err.message : "Couldn't check the key.", "err");
  }
}
async function init() {
  settings = await loadSettings();
  renderProviders();
  showProvider();
  $("max-chars").value = String(settings.maxChars);
  $("include-links").checked = settings.includeLinks;
  $("form").onsubmit = (e) => void save(e);
  $("test").onclick = () => void test();
  $("toggle-key").onclick = () => {
    const input = $("key");
    input.type = input.type === "password" ? "text" : "password";
    $("toggle-key").textContent = input.type === "password" ? "Show" : "Hide";
  };
  $("wipe").onclick = async () => {
    if (!confirm("Delete your saved API keys and settings from this browser?")) return;
    await chrome.storage.local.clear();
    await chrome.storage.session.clear();
    await chrome.permissions.remove({ origins: PROVIDER_IDS.map((i) => PROVIDERS[i].origin) });
    settings = normalizeSettings({});
    renderProviders();
    showProvider();
    say("All PageSift data deleted.", "ok");
  };
}
void init();
