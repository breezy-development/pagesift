// src/lib/columns.ts
var PRESETS = [
  { id: "auto", label: "Let AI choose columns", columns: "" },
  { id: "products", label: "Products", columns: "Name, Price, Rating, Reviews, URL" },
  { id: "articles", label: "Articles / posts", columns: "Title, Author, Date, Summary, URL" },
  { id: "events", label: "Events", columns: "Event, Date, Time, Venue, City, URL" },
  { id: "jobs", label: "Job listings", columns: "Title, Company, Location, Salary, Posted, URL" },
  { id: "table", label: "Main table on page", columns: "", hint: "Copy the main data table on the page, keeping its own headers." }
];

// src/lib/page.ts
function collectPage(maxLinks) {
  const clean = (s) => s.replace(/[ \t\u00a0]+/g, " ").replace(/\n{3,}/g, "\n\n").trim();
  const selection = window.getSelection();
  const selected = selection && !selection.isCollapsed ? selection.toString() : "";
  let root = document.body;
  const main = document.querySelector("main, [role=main], article");
  if (main instanceof HTMLElement && main.innerText.trim().length > 500) root = main;
  const fromSelection = selected.trim().length > 40;
  const text = fromSelection ? selected : root.innerText || root.textContent || "";
  const links = [];
  const seen = /* @__PURE__ */ new Set();
  const range = fromSelection && selection && selection.rangeCount ? selection.getRangeAt(0) : null;
  for (const a of Array.from(root.querySelectorAll("a[href]"))) {
    if (links.length >= maxLinks) break;
    const el = a;
    if (range && !range.intersectsNode(el)) continue;
    if (!/^https?:$/.test(el.protocol)) continue;
    const url = new URL(el.href);
    url.hash = "";
    const href = url.href;
    if (seen.has(href)) continue;
    const label = clean(el.innerText || el.getAttribute("aria-label") || el.querySelector("img")?.alt || "");
    if (!label) continue;
    seen.add(href);
    links.push({ text: label.slice(0, 120), href });
  }
  return { url: location.href, title: document.title, text: clean(text), links, fromSelection };
}
function snapshotToPromptText(page, maxChars, includeLinks = true) {
  const linkLines = includeLinks ? page.links.map((l) => `- ${l.text} <${l.href}>`) : [];
  const linkBudget = linkLines.length ? Math.floor(maxChars / 4) : 0;
  let linksBlock = "";
  let linksTruncated = false;
  for (const line of linkLines) {
    if (linksBlock.length + line.length + 1 > linkBudget) {
      linksTruncated = true;
      break;
    }
    linksBlock += line + "\n";
  }
  const textBudget = maxChars - linksBlock.length;
  const textTruncated = page.text.length > textBudget;
  const body = textTruncated ? page.text.slice(0, textBudget) : page.text;
  const parts = [body];
  if (linksBlock) parts.push(`
Links on the page (text <url>):
${linksBlock.trimEnd()}`);
  return { text: parts.join("\n"), truncated: textTruncated || linksTruncated };
}
function hostOf(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
}
function isRestrictedUrl(url) {
  if (!url) return true;
  if (/^(chrome|edge|brave|about|devtools|view-source|chrome-extension|chrome-search):/i.test(url)) return true;
  return /^https:\/\/(chromewebstore\.google\.com|chrome\.google\.com\/webstore)/i.test(url);
}

// src/lib/plan.ts
var PLANS = {
  free: { tier: "free", maxChars: 6e4, maxColumns: 12, savedTemplates: 0 },
  pro: { tier: "pro", maxChars: 12e4, maxColumns: 30, savedTemplates: 50 }
};
var source = async () => "free";
async function getPlan() {
  try {
    return PLANS[await source()] ?? PLANS.free;
  } catch {
    return PLANS.free;
  }
}

// src/lib/prompt.ts
var SUMMARY_STYLES = {
  bullets: { label: "Key points", ask: 'Summarize the page as 4-7 short bullet points (start each line with "- ").' },
  tldr: { label: "TL;DR", ask: "Summarize the page in one short paragraph of at most 3 sentences." },
  actions: {
    label: "Action items",
    ask: 'List the concrete action items, deadlines, prices or decisions on the page as bullet points (start each line with "- "). If there are none, say so in one line.'
  }
};

// src/lib/settings.ts
var PROVIDERS = {
  openai: {
    label: "OpenAI",
    origin: "https://api.openai.com/*",
    defaultModel: "gpt-5.4-mini",
    keyPrefix: "sk-",
    keyUrl: "https://platform.openai.com/api-keys"
  },
  anthropic: {
    label: "Anthropic",
    origin: "https://api.anthropic.com/*",
    defaultModel: "claude-haiku-4-5",
    keyPrefix: "sk-ant-",
    keyUrl: "https://console.anthropic.com/settings/keys"
  },
  openrouter: {
    label: "OpenRouter",
    origin: "https://openrouter.ai/*",
    defaultModel: "openai/gpt-5.4-mini",
    keyPrefix: "sk-or-",
    keyUrl: "https://openrouter.ai/settings/keys"
  }
};
var PROVIDER_IDS = Object.keys(PROVIDERS);
var MIN_CHARS = 2e3;
var MAX_CHARS = 12e4;
var DEFAULT_SETTINGS = {
  provider: "openai",
  keys: { openai: "", anthropic: "", openrouter: "" },
  models: { openai: "", anthropic: "", openrouter: "" },
  maxChars: 3e4,
  includeLinks: true
};
function isProvider(value) {
  return typeof value === "string" && value in PROVIDERS;
}
function strings(raw) {
  const out = { openai: "", anthropic: "", openrouter: "" };
  if (raw && typeof raw === "object") {
    for (const id of PROVIDER_IDS) {
      const v = raw[id];
      if (typeof v === "string") out[id] = v.trim();
    }
  }
  return out;
}
function normalizeSettings(raw) {
  const r = raw && typeof raw === "object" ? raw : {};
  const chars = Number(r.maxChars);
  return {
    provider: isProvider(r.provider) ? r.provider : DEFAULT_SETTINGS.provider,
    keys: strings(r.keys),
    models: strings(r.models),
    maxChars: Number.isFinite(chars) ? Math.min(MAX_CHARS, Math.max(MIN_CHARS, Math.round(chars))) : DEFAULT_SETTINGS.maxChars,
    includeLinks: typeof r.includeLinks === "boolean" ? r.includeLinks : DEFAULT_SETTINGS.includeLinks
  };
}
function activeKey(s) {
  return s.keys[s.provider];
}
function activeModel(s) {
  return s.models[s.provider] || PROVIDERS[s.provider].defaultModel;
}
function maskKey(key) {
  if (!key) return "";
  if (key.length <= 10) return "\u2022".repeat(key.length);
  return `${key.slice(0, 6)}\u2026${key.slice(-4)}`;
}
var STORAGE_KEY = "settings";
async function loadSettings(storage = chrome.storage.local) {
  const got = await storage.get(STORAGE_KEY);
  return normalizeSettings(got[STORAGE_KEY]);
}

// src/lib/table.ts
var FORMULA_START = /^[=+\-@\t\r]/;
var PLAIN_NUMBER = /^[+-]?(\d[\d,]*)?(\.\d+)?%?$/;
function safeCell(value) {
  return FORMULA_START.test(value) && !PLAIN_NUMBER.test(value) ? `'${value}` : value;
}
function csvField(value) {
  const v = safeCell(value);
  return /[",\r\n]|^\s|\s$/.test(v) ? `"${v.replace(/"/g, '""')}"` : v;
}
function toCSV(table) {
  return [table.headers, ...table.rows].map((r) => r.map(csvField).join(",")).join("\r\n") + "\r\n";
}
function toTSV(table) {
  return [table.headers, ...table.rows].map((r) => r.map((v) => safeCell(v).replace(/[\t\r\n]+/g, " ")).join("	")).join("\n");
}
function toJSONRecords(table) {
  return table.rows.map((r) => Object.fromEntries(table.headers.map((h, i) => [h, r[i] ?? ""])));
}
function exportFilename(host, date, ext) {
  const day = date.toISOString().slice(0, 10);
  const safeHost = host.replace(/[^a-z0-9.-]+/gi, "-").replace(/^-+|-+$/g, "") || "page";
  return `pagesift-${safeHost}-${day}.${ext}`;
}

// src/lib/run.ts
function runKey(tabId) {
  return `run:${tabId}`;
}

// src/lib/text.ts
function bulletItems(text) {
  const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  if (lines.length < 2 || !lines.every((l) => /^[-*•]\s+/.test(l))) return null;
  return lines.map((l) => l.replace(/^[-*•]\s+/, ""));
}

// src/popup/popup.ts
var $ = (id) => document.getElementById(id);
var DEFAULT_DRAFT = { mode: "extract", preset: "products", columns: PRESETS[1].columns, instructions: "", style: "bullets" };
var settings;
var plan;
var tab;
var draft = { ...DEFAULT_DRAFT };
var hasPermission = false;
var lastTable = null;
var lastSummary = "";
function show(id, visible) {
  $(id).hidden = !visible;
}
function setMode(mode) {
  draft.mode = mode;
  $("tab-extract").setAttribute("aria-selected", String(mode === "extract"));
  $("tab-summary").setAttribute("aria-selected", String(mode === "summary"));
  show("extract-panel", mode === "extract");
  show("summary-panel", mode === "summary");
}
function setBusy(busy, text = "") {
  show("status", busy);
  $("status-text").textContent = text;
  for (const id of ["run-extract", "run-summary"]) $(id).disabled = busy;
}
function showError(message, action) {
  setBusy(false);
  $("error-text").textContent = message;
  const btn = $("error-action");
  btn.hidden = !action;
  if (action) {
    btn.textContent = action.label;
    btn.onclick = action.run;
  }
  show("error", true);
}
function clearMessages() {
  show("error", false);
  show("result", false);
}
async function saveDraft() {
  await chrome.storage.local.set({ draft });
}
function buildControls() {
  const select = $("preset");
  select.append(new Option("Custom columns", "custom"));
  for (const p of PRESETS) select.append(new Option(p.label, p.id));
  const seg = $("styles");
  for (const [id, s] of Object.entries(SUMMARY_STYLES)) {
    const label = document.createElement("label");
    const input = document.createElement("input");
    input.type = "radio";
    input.name = "style";
    input.value = id;
    label.append(input, s.label);
    seg.append(label);
  }
}
function applyDraft() {
  $("preset").value = draft.preset;
  $("columns").value = draft.columns;
  $("instructions").value = draft.instructions;
  if (draft.instructions) $("more").open = true;
  const radio = document.querySelector(`input[name="style"][value="${draft.style}"]`);
  if (radio) radio.checked = true;
  setMode(draft.mode);
}
function readForm() {
  draft.columns = $("columns").value.trim();
  draft.instructions = $("instructions").value.trim();
  draft.preset = $("preset").value;
  const style = document.querySelector('input[name="style"]:checked')?.value;
  if (style && style in SUMMARY_STYLES) draft.style = style;
}
async function ensurePermission() {
  if (hasPermission) return true;
  try {
    hasPermission = await chrome.permissions.request({ origins: [PROVIDERS[settings.provider].origin] });
  } catch {
    hasPermission = false;
  }
  return hasPermission;
}
function permissionError() {
  const host = new URL(PROVIDERS[settings.provider].origin.replace("/*", "/")).host;
  showError(`PageSift needs your OK to send requests to ${host}.`, {
    label: "Allow",
    run: async () => {
      if (await ensurePermission()) show("error", false);
    }
  });
}
async function readPage() {
  const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: collectPage, args: [400] });
  if (!res?.result) throw new Error("no result");
  return res.result;
}
async function run(mode) {
  if (!await ensurePermission()) return permissionError();
  readForm();
  draft.mode = mode;
  void saveDraft();
  clearMessages();
  setBusy(true, "Reading the page\u2026");
  let page;
  try {
    page = await readPage();
  } catch {
    return showError("Couldn't read this page. Reload it and try again.");
  }
  const { text, truncated } = snapshotToPromptText(page, Math.min(settings.maxChars, plan.maxChars), settings.includeLinks);
  if (text.trim().length < 20) return showError("There's no readable text on this page.");
  const base = {
    tabId: tab.id,
    url: page.url,
    title: page.title,
    pageText: text,
    truncated,
    fromSelection: page.fromSelection
  };
  const job = mode === "extract" ? { ...base, mode, columns: draft.columns, instructions: draft.instructions } : { ...base, mode, style: draft.style };
  const msg = { type: "run", job };
  await chrome.runtime.sendMessage(msg);
}
function cellNode(value) {
  if (/^https?:\/\/\S+$/.test(value)) {
    const a = document.createElement("a");
    a.href = value;
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    const u = new URL(value);
    a.textContent = u.hostname.replace(/^www\./, "") + (u.pathname.length > 1 ? u.pathname : "");
    return a;
  }
  return document.createTextNode(value);
}
function renderTable(t) {
  const table = $("table");
  table.replaceChildren();
  const head = table.createTHead().insertRow();
  head.append(Object.assign(document.createElement("th"), { textContent: "#" }));
  for (const h of t.headers) head.append(Object.assign(document.createElement("th"), { textContent: h }));
  const body = table.createTBody();
  t.rows.slice(0, 200).forEach((r, i) => {
    const tr = body.insertRow();
    const num = tr.insertCell();
    num.className = "num";
    num.textContent = String(i + 1);
    for (const v of r) {
      const td = tr.insertCell();
      td.title = v;
      td.append(cellNode(v));
    }
  });
}
function render(state) {
  if (!state || state.url !== tab.url) return;
  if (state.status === "running") {
    show("error", false);
    show("result", false);
    setBusy(true, `Asking ${state.model}\u2026`);
    return;
  }
  setBusy(false);
  if (state.status === "error") {
    if (state.kind === "cancelled") return;
    if (state.kind === "auth") return showError(state.message, { label: "Settings", run: () => chrome.runtime.openOptionsPage() });
    if (state.kind === "network" && !hasPermission) return permissionError();
    return showError(state.message);
  }
  setMode(state.mode);
  show("result", true);
  show("error", false);
  const warnings = [];
  if (state.truncated) warnings.push("The page was long, so only the first part was read. Select a section, or raise the limit in Settings.");
  if (state.fromSelection) warnings.push("Used only the text you selected.");
  const tokens = state.tokens ? ` \xB7 ${state.tokens.toLocaleString()} tokens` : "";
  $("result-meta").textContent = `${state.model}${tokens}`;
  const isTable = state.mode === "extract" && state.table;
  show("table-wrap", Boolean(isTable && state.table.rows.length));
  show("table-actions", Boolean(isTable && state.table.rows.length));
  show("summary-out", !isTable);
  show("summary-actions", !isTable);
  if (isTable) {
    lastTable = state.table;
    const { rows, headers } = lastTable;
    $("result-title").textContent = `${rows.length} ${rows.length === 1 ? "row" : "rows"} \xD7 ${headers.length} columns`;
    if (rows.length) renderTable(lastTable);
    else warnings.unshift("No matching rows found. Try other columns, or select the part of the page that has the data.");
    if (rows.length > 200) warnings.push("Preview shows the first 200 rows; exports include all of them.");
  } else {
    lastSummary = state.summary ?? "";
    $("result-title").textContent = "Summary";
    const out = $("summary-out");
    const items = bulletItems(lastSummary);
    if (items) {
      const ul = document.createElement("ul");
      for (const item of items) ul.append(Object.assign(document.createElement("li"), { textContent: item }));
      out.replaceChildren(ul);
    } else {
      out.textContent = lastSummary;
    }
  }
  show("tip", false);
  $("warn").textContent = warnings.join(" ");
  show("warn", warnings.length > 0);
}
async function copy(button, text) {
  await navigator.clipboard.writeText(text);
  const old = button.textContent;
  button.textContent = "Copied \u2713";
  setTimeout(() => button.textContent = old, 1200);
}
function download() {
  if (!lastTable) return;
  const blob = new Blob(["\uFEFF" + toCSV(lastTable)], { type: "text/csv;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = exportFilename(hostOf(tab.url ?? ""), /* @__PURE__ */ new Date(), "csv");
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 5e3);
}
function wire() {
  $("open-settings").onclick = () => chrome.runtime.openOptionsPage();
  $("setup-btn").onclick = () => chrome.runtime.openOptionsPage();
  $("tab-extract").onclick = () => setMode("extract");
  $("tab-summary").onclick = () => setMode("summary");
  $("extract-panel").onsubmit = (e) => {
    e.preventDefault();
    void run("extract");
  };
  $("summary-panel").onsubmit = (e) => {
    e.preventDefault();
    void run("summary");
  };
  $("preset").onchange = (e) => {
    const p = PRESETS.find((x) => x.id === e.target.value);
    if (!p) return;
    $("columns").value = p.columns;
    $("instructions").value = p.hint ?? "";
    readForm();
    void saveDraft();
  };
  $("columns").oninput = (e) => {
    const value = e.target.value.trim();
    const match = PRESETS.find((p) => p.columns && p.columns === value);
    $("preset").value = match ? match.id : value ? "custom" : "auto";
  };
  $("cancel").onclick = () => {
    const msg = { type: "cancel", tabId: tab.id };
    void chrome.runtime.sendMessage(msg);
    setBusy(false);
  };
  $("dl-csv").onclick = download;
  $("copy-tsv").onclick = (e) => lastTable && copy(e.currentTarget, toTSV(lastTable));
  $("copy-json").onclick = (e) => lastTable && copy(e.currentTarget, JSON.stringify(toJSONRecords(lastTable), null, 2));
  $("copy-summary").onclick = (e) => copy(e.currentTarget, lastSummary);
}
async function init() {
  [settings, plan] = await Promise.all([loadSettings(), getPlan()]);
  [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  $("page-host").textContent = hostOf(tab.url ?? "") || "this page";
  $("page-title").textContent = tab.title || tab.url || "";
  const key = activeKey(settings);
  $("model-line").textContent = key ? `${activeModel(settings)} via ${PROVIDERS[settings.provider].label} \xB7 key ${maskKey(key)} (stored on this device)` : "No API key yet";
  wire();
  if (!key) return show("setup", true);
  if (isRestrictedUrl(tab.url)) return show("restricted", true);
  show("main", true);
  buildControls();
  const stored = await chrome.storage.local.get("draft");
  draft = { ...DEFAULT_DRAFT, ...stored.draft };
  applyDraft();
  hasPermission = await chrome.permissions.contains({ origins: [PROVIDERS[settings.provider].origin] });
  const k = runKey(tab.id);
  render((await chrome.storage.session.get(k))[k]);
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "session" && changes[k]) render(changes[k].newValue);
  });
}
void init();
